(() => {
  const normalize = s => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  function describe(el) {
    const id = el.id || '';
    const labels = [...(el.labels || [])].map(x => x.textContent).join(' ');
    const nearby = el.closest('td, div, p, fieldset, tr')?.textContent?.slice(0, 180) || '';
    const label = normalize([labels, el.getAttribute('aria-label'), el.placeholder, el.name, id].filter(Boolean).join(' '));
    return {element: el, label, nearby: normalize(nearby), type: el.tagName.toLowerCase(), disabled: el.disabled, readonly: el.readOnly, options: el.tagName === 'SELECT' ? el.options.length : null};
  }
  function find() {
    const all = [...document.querySelectorAll('input:not([type=hidden]), select, textarea')].map(describe);
    return all.filter(x => /cidade|municipio|naturalidade/.test(x.label) || (/cidade|municipio/.test(x.nearby) && x.nearby.length < 110));
  }
  function inspect() {
    return find().map((x, i) => ({index: i + 1, name: x.element.name || x.element.id || '(sem identificador)', type: x.type, disabled: x.disabled, readonly: !!x.readonly, options: x.options, label: x.label.slice(0, 100)}));
  }
  function help(index) {
    const item = find()[index];
    if (!item) return {ok:false, message:'Campo não encontrado.'};
    const el = item.element;
    el.scrollIntoView({behavior:'smooth', block:'center'});
    el.style.outline = '3px solid #1680d3';
    setTimeout(() => { el.style.outline = ''; }, 3000);
    if (el.disabled) return {ok:false, message:'Campo desabilitado pelo próprio site. Selecione primeiro país/UF e aguarde o carregamento. A extensão não altera essa regra.'};
    if (el.readOnly) return {ok:false, message:'Campo somente leitura definido pelo site. Verifique os campos anteriores.'};
    el.focus();
    if (el.tagName === 'SELECT') {
      if (el.options.length < 2) return {ok:false, message:'Lista sem opções. Pode haver falha no carregamento pelo servidor; tente selecionar novamente a UF.'};
      return {ok:true, message:'Lista encontrada e focalizada. Use as teclas para selecionar uma opção oficial.'};
    }
    return {ok:true, message:'Campo de texto encontrado e focalizado. Tente digitar normalmente.'};
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'inspect') sendResponse({fields:inspect()});
    else if (msg.action === 'help') sendResponse(help(msg.index));
  });
})();
