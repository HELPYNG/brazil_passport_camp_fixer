# Diagnóstico Cidade — Polícia Federal

Extensão Chrome Manifest V3, sem envio de dados para terceiros. Ela identifica campos potencialmente relacionados a cidade, município ou naturalidade, exibe o estado do controle e ajuda a localizar/focalizar o campo nativo. Não desabilita validações, não injeta opções, não altera valores enviados e não resolve falhas no servidor da PF.

## Instalação
1. Extraia o ZIP.
2. Abra `chrome://extensions` no Chrome.
3. Ative **Modo do desenvolvedor**.
4. Clique **Carregar sem compactação** e escolha a pasta `pf-cidade-helper`.
5. Atualize a página do formulário da PF, clique no ícone da extensão e em **Analisar campos**.

## Para continuar no Codex no seu PC
Abra esta pasta no Codex e peça: "Inspecione o comportamento dos campos Cidade/Município do site da Polícia Federal no navegador, identifique os IDs e dependências reais de País/UF e aprimore esta extensão sem contornar validações oficiais. Não leia, armazene nem envie dados pessoais do formulário. Adicione testes e registre erros de carregamento." 

## Limitações
A identificação usa heurísticas de rótulos e pode gerar falsos positivos. Campos que dependem de respostas do servidor ou scripts quebrados podem exigir correção pela PF. Não preencha dados pessoais durante o diagnóstico.
