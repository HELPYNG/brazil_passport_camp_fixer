const list = document.getElementById('list');
const status = document.getElementById('status');
async function send(message) {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.id || !tab.url?.startsWith('https://servicos.pf.gov.br/sinpa/')) throw Error('Abra o formulário da Polícia Federal e atualize a página.');
  return chrome.tabs.sendMessage(tab.id, message);
}
async function scan() {
  list.replaceChildren(); status.textContent = '';
  try {
    const {fields} = await send({action:'inspect'});
    if (!fields.length) {status.textContent='Nenhum campo identificado. O site pode usar rótulos diferentes ou componentes dinâmicos.';return;}
    fields.forEach((f, i) => {
      const li = document.createElement('li');
      const title = document.createElement('strong'); title.textContent = f.name;
      const detail = document.createElement('small'); detail.textContent = `${f.type} · ${f.disabled ? 'desabilitado' : f.readonly ? 'somente leitura' : 'habilitado'}${f.options !== null ? ` · ${f.options} opções` : ''}`;
      const btn = document.createElement('button'); btn.textContent='Localizar e testar';
      btn.addEventListener('click', async () => {try {const result = await send({action:'help',index:i}); status.textContent=result.message;}catch(e){status.textContent=e.message;}});
      li.append(title,detail,btn);list.append(li);
    });
  } catch(e) {status.textContent=e.message;}
}
document.getElementById('scan').addEventListener('click',scan);
scan();
